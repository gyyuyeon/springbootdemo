package com.company;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Spring03ShopApplication {

	public static void main(String[] args) {
		SpringApplication.run(Spring03ShopApplication.class, args);
	}

}
