package com.company;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Spring02TodolistMavenApplication {

	public static void main(String[] args) {
		SpringApplication.run(Spring02TodolistMavenApplication.class, args);
	}

}
