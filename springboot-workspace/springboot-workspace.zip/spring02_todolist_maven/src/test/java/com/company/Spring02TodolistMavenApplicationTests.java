package com.company;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Spring02TodolistMavenApplicationTests {

	@Test
	void contextLoads() {
	}

}
