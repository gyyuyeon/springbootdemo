package com.example;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Spring01MvcApplicationTests {

	@Test
	void contextLoads() {
	}

}
